
var ilkuc=document.querySelectorAll('.picture');
var txt2=document.querySelectorAll(".all");
var head=document.querySelectorAll(".header-tx")
txt2.forEach(i=>i.addEventListener("click",show));
function show(){
  var txt=document.getElementById("part12");

  
  txt.classList.toggle('showtext');
if(this.innerText=="Webdesign"){
   head[0].innerText="Webdesign";
}
if(this.innerText=="Photography"){
  head[0].innerText="Photography";
}
if(this.innerText=="Print design"){
  head[0].innerText="Print design";
}
if(this.innerText=="Ecommerce development"){
  head[0].innerText="Ecommerce development";
}
if(this.innerText=="SEO Services"){
  head[0].innerText="SEO Services";
}
if(this.innerText=="WP Development"){
  head[0].innerText="WP Development";
}
}

// if(txt.classList.contains("showtext")){
//   function showPage() {
//   document.getElementById("loader").style.display = "none";
// }
//  function myFunction() {
//   myVar = setTimeout(showPage, 0);
// }
// }

// var myVar;








function classToggle() {
    const navs = document.querySelectorAll('.Navbar__Items')
    
    navs.forEach(nav => nav.classList.toggle('Navbar__ToggleShow'));
  }
  
  document.querySelector('.Navbar__Link-toggle')
    .addEventListener('click', classToggle);
  





// slider


var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
}



// effect 1




// function showtext(){
 
  

// }